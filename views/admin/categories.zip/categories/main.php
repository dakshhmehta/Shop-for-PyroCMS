<!--- FILE.START:VIEW.ADMIN.CATEGORY.MAIN --->
<div class="one_half">
	<section class="title">
			  <h4><?php echo lang('categories'); ?></h4>
			  <h4 style="float:right"><a id="categories-new-btn" href="admin/shop/categories/create/" style="margin:2px;"  class='button'><?php echo lang('new');?></a></h4>	 
	</section>
	<section class="item">
		<div id="categories-list">
		<ul class="sortable">
		 <?php foreach ($categories as $category):?>
			<li id="<?php echo $category->id;?>"><div><a  class=""  id="<?php echo $category->id;?>" href="admin/shop/categories/edit/<?php echo $category->id;?>" rel="<?php echo $category->id;?>"><?php echo $category->name;?></a></div></li> 
		<?php endforeach;?>
		</ul>
		</div>
	</section>
</div>
<div class="one_half last scroll-follow">	

	<section class="title">
			  <h4><?php echo lang('details');?></h4>
	</section>
	<section class="item">	
		<div id="categories-details">
		</div>
	</section>
</div>
<!--- FILE.END:VIEW.ADMIN.CATEGORY.MAIN --->
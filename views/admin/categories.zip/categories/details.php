<!--- FILE.START:VIEW.ADMIN.CATEGORIES.DETAILS --->
<?php #echo form_open(uri_string(), 'id="category-' . $this->method . '" class="form_inputs"'); ?>  
		<div id="categories-list">
				<div class="form_inputs" id="name-tab">
					<fieldset>
						<ul>
							<li>
								<label>Image</label>
								<div id='cover_img' name='cover_img'>
								 <?php if ($category->image_id > 0) {echo '<img src="'.site_url().'files/thumb/'.$category->image_id.'/100/100">'; }; ?>
								</div>   
							</li>							
							<li>
								<label><?php echo lang('name');?></label>
								<?php echo $category->name; ?> 
							</li>
							<li>
								<label><?php echo lang('slug');?></label>							
								<?php echo $category->slug ; ?>	  
							</li>						
							<li>
								<label><?php echo lang('description');?></label>
								<?php echo $category->description; ?> 
							</li>
						</ul>
					</fieldset>
				</div>
			
			</div>
			
	 <div class="buttons float-left padding-top">  
	 
		<a cat='<?php echo $category->id; ?>' style='' id='categories-edit-btn' class='button'  class='button' href="admin/shop/categories/edit/<?php echo $category->id; ?>"><?php echo lang('edit');?></a>	
		<a cat='<?php echo $category->id; ?>' style='color:red' class='confirm button red delete' href="<?php echo $url; ?>admin/shop/categories/delete/<?php echo $category->id; ?>"><?php echo lang('delete');?></a> 
	</div>	
<?php # echo form_close(); ?>
<!--- FILE.END:VIEW.ADMIN.CATEGORIES.DETAILS --->
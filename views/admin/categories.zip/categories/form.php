<!--- FILE.START:VIEW.ADMIN.CATEGORIES.FORM --->
<?php echo form_open(uri_string(), 'id="category-' . $this->method . '" class="form_inputs"'); ?>  
<?php if ( $this->method=='edit') { echo form_hidden('id', $category->id, 'maxlength="100" class="text"'); } ?>

	<div class="tabs">
		
		<ul class="tab-menu">			
			<li><a href="#name-tab"><span><?php echo lang('details');?></span></a></li>
		</ul>

		<div class="form_inputs" id="name-tab">
			<fieldset>
					<ul>
						<li>
							<label><?php echo lang('name');?><span>*</span></label>
							<?php echo form_input('name', $category->name, 'maxlength="100" class="text"'); ?>
						</li>
						<!-- li>
							<label><?php echo lang('uri');?><span>*</span></label>
							<?php echo form_input('slug', $category->slug, 'maxlength="100" class="text" readonly="readonly" contenteditable="FALSE"'); ?>   
						</li--->
					
						<li>
							<label><?php echo lang('description');?></label>
							 <?php echo form_textarea('description', $category->description, 'rows="20" id="description" cols="30" class="" style="max-width:420px;resize: vertical;"'); ?>	   
						</li>		
	
						<li>
							<label>Current Image</label>
							<div id='cover_img' name='cover_img'>
							 <?php if ($category->image_id > 0) {echo '<img src="'.site_url().'files/thumb/'.$category->image_id.'/100/100">'; }; ?>
							</div>   
						</li>	
						<li>
							<label>Change Image</label>
							 <?php echo form_dropdown('folder_id', $folders, $folder_id, 'id="folder_id"'); ?>	   
						</li>																	
						<li>
							<label></label>
							<?php echo "<a href='#' id='load_folder' name='load_folder' style='display:none;' >Load</a>"; ?>

								   <div id='img_view' style="overflow-y:scroll;min-height:50px;max-height:300px;">
										<!-- This is where the response from search folder images goes -->
								   </div>		
						</li>									
									
	
					</ul>
			</fieldset>
			
		</div>

	</div>

	<div id="details-container">	

	  <div class="buttons float-left padding-top">		
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'cancel'))); ?>	
	  </div>	

	</div>

<?php echo form_close(); ?>

<script>

	function set_img(o) {
	
		//alert(o.value);
	
		cid = <?php echo $category->id; ?>; 
		
		$.post('shop/admin/categories/set_cover', { image_id:o.value, cat_id:cid } )
		
			.done(function(data) 
			{			
				var obj = jQuery.parseJSON(data);
	
				//alert(obj.html);
				if (obj.status == 'success') 
				{
					$('#cover_img').html(obj.html);	
				}
			}

			
		);
		
	}

	$(document).ready(function() 
	{





		//will set in the db
		$('#load_folder').click(function() 
		{
			
			/* Get the values to send to the server */
			f_id = $('#folder_id').val();

			
			var senddata = { folder_id:f_id  };
			
			$.post('shop/admin/images/get_folder_contents', senddata )

			.done(function(data) 
			{
				var obj = jQuery.parseJSON(data);
				
				str = '';
				for (var i = 0; i < obj.length; i++) 
				{
					
					str += "<div class='container'>";
					str += "   <img src='" + obj.url + 'files/thumb/' + obj.content[i] + "/100/100' alt='' style='float:left'>";
					str += "   <input onclick='set_img(this)' type='radio' class='gall_checkbox' id='images[]' name='images[]' value='" + obj.content[i] + "' />";
					str += "</div>";
				}

				$('#img_view').html(str);
				
			});
			
			return false;
		
		});

		$("#folder_id").chosen().change(function() {
			//alert(+$(this).val());
			$('#load_folder').click();
			//$('#' + $(this).val()).show();
		});		

	});
	
</script>
<!--- FILE.END:VIEW.ADMIN.CATEGORIES.FORM --->
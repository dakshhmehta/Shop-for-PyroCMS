<!--- FILE.START:VIEW.ADMIN.CATEGORIES.FORM --->
<?php echo form_open(uri_string(), 'id="category-' . $this->method . '" class="form_inputs"'); ?>  
<?php if ( $this->method=='edit') { echo form_hidden('id', $category->id, 'maxlength="100" class="text"'); } ?>
	<div class="tabs">
		
		<ul class="tab-menu">			
			<li><a href="#name-tab"><span><?php echo lang('details');?></span></a></li>
		</ul>
		<div class="form_inputs" id="name-tab">
			<fieldset>
					<ul>
						<li>
							<label><?php echo lang('name');?><span>*</span></label>
							<?php echo form_input('name', $category->name, 'maxlength="100" class="text"'); ?>
						</li>
						<!-- li>
							<label><?php echo lang('uri');?><span>*</span></label>
							<?php echo form_input('slug', $category->slug, 'maxlength="100" class="text" readonly="readonly" contenteditable="FALSE"'); ?>   
						</li--->
					
						<li>
							<label><?php echo lang('description');?></label>
							 <?php echo form_textarea('description', $category->description, 'rows="20" id="description" cols="30" class="" style="max-width:420px;resize: vertical;"'); ?>	   
						</li>										

					</ul>
			</fieldset>
			
		</div>

	</div>

	<div id="details-container">	

	  <div class="buttons float-left padding-top">		
		<?php $this->load->view('admin/partials/buttons', array('buttons' => array('save', 'cancel'))); ?>	
	  </div>	

	</div>

<?php echo form_close(); ?>
<!--- FILE.END:VIEW.ADMIN.CATEGORIES.FORM --->